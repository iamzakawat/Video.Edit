# Ghabooleh lyric video

Repo root must contain: song.mp3, bg.jpg, lyrics.txt, project.zip
1. Actions -> Render -> Run workflow (Preview = true) -> check the 20s clip in Releases
2. Fix timings in lyrics.txt, then run again with Preview = false
3. Download ghabooleh.mp4 and ghabooleh-vertical.mp4 from the Release assets
