import React from 'react';
import {
  AbsoluteFill,
  Audio,
  Img,
  interpolate,
  random,
  spring,
  staticFile,
  useCurrentFrame,
  useVideoConfig,
} from 'remotion';
import {useAudioData, visualizeAudio} from '@remotion/media-utils';
import {loadFont} from '@remotion/google-fonts/Vazirmatn';
import type {Line} from './parse';

const {fontFamily} = loadFont('normal', {
  weights: ['700'],
  subsets: ['arabic', 'latin'],
});

export type Props = {lines: Line[]; vertical: boolean; offset: number};

const SPEAKERS: Record<string, {color: string; label: string}> = {
  Male: {color: '#F2B04A', label: 'ناخدا'},
  Female: {color: '#F0583A', label: 'دختر بندر'},
  Both: {color: '#FFF8EC', label: 'هر دو'},
  Crowd: {color: '#FFF8EC', label: 'همه'},
};

const Particles: React.FC = () => {
  const frame = useCurrentFrame();
  const {height} = useVideoConfig();
  return (
    <AbsoluteFill style={{pointerEvents: 'none'}}>
      {Array.from({length: 36}).map((_, i) => {
        const x = random(`x${i}`) * 100;
        const size = 2 + random(`s${i}`) * 5;
        const speed = 0.3 + random(`v${i}`) * 0.6;
        const y =
          (((random(`y${i}`) * height - frame * speed * 2) % height) + height) % height;
        const op = 0.2 + random(`o${i}`) * 0.5;
        return (
          <div
            key={i}
            style={{
              position: 'absolute',
              left: `${x}%`,
              top: y,
              width: size,
              height: size,
              borderRadius: '50%',
              background: '#F2B04A',
              opacity: op,
              boxShadow: '0 0 12px #F2B04A',
            }}
          />
        );
      })}
    </AbsoluteFill>
  );
};

export const LyricVideo: React.FC<Props> = ({lines, vertical, offset}) => {
  const frame = useCurrentFrame();
  const {fps, durationInFrames} = useVideoConfig();
  const t = frame / fps + offset;
  const audioData = useAudioData(staticFile('song.mp3'));

  let pulse = 1;
  if (audioData) {
    const v = visualizeAudio({
      fps,
      frame: frame + Math.round(offset * fps),
      audioData,
      numberOfSamples: 32,
    });
    const bass = (v[0] + v[1] + v[2] + v[3]) / 4;
    pulse = 1 + Math.min(bass * 0.5, 0.03);
  }

  const zoom = interpolate(frame, [0, durationInFrames], [1, 1.08]);

  let idx = -1;
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].start <= t) idx = i;
    else break;
  }
  const cur = idx >= 0 ? lines[idx] : null;
  const prev = idx > 0 ? lines[idx - 1] : null;

  const startF = cur ? Math.round((cur.start - offset) * fps) : 0;
  const local = Math.max(0, frame - startF);
  const enter = spring({frame: local, fps, config: {damping: 200}});

  const isHit = !!cur && cur.text.replace(/[؟?!\s]/g, '') === 'قبوله';
  const hit = isHit ? spring({frame: local, fps, config: {damping: 8, stiffness: 200}}) : 1;
  const hitScale = isHit ? 0.75 + 0.25 * hit : 1;
  const flash = isHit ? interpolate(local, [0, 6], [0.25, 0], {extrapolateRight: 'clamp'}) : 0;

  const fadeIn = offset === 0 ? interpolate(frame, [0, 30], [1, 0], {extrapolateRight: 'clamp'}) : 0;
  const fadeOut = interpolate(frame, [durationInFrames - 45, durationInFrames], [0, 1], {
    extrapolateLeft: 'clamp',
  });

  const fontSize = vertical ? 84 : 104;
  const sp = cur ? SPEAKERS[cur.speaker] ?? SPEAKERS.Both : SPEAKERS.Both;

  const textStyle: React.CSSProperties = {
    fontFamily,
    direction: 'rtl',
    textAlign: 'center',
    width: '86%',
    lineHeight: 1.45,
    position: 'absolute',
  };

  return (
    <AbsoluteFill style={{backgroundColor: '#06141C', fontFamily}}>
      <Audio src={staticFile('song.mp3')} startFrom={Math.round(offset * fps)} />

      <AbsoluteFill style={{overflow: 'hidden'}}>
        <Img
          src={staticFile('bg.jpg')}
          style={{
            width: '100%',
            height: '100%',
            objectFit: 'cover',
            transform: `scale(${zoom * pulse})`,
          }}
        />
      </AbsoluteFill>

      <AbsoluteFill
        style={{
          background:
            'linear-gradient(to top, rgba(6,20,28,0.88), rgba(6,20,28,0.35) 50%, rgba(6,20,28,0.65))',
        }}
      />
      <Particles />

      <AbsoluteFill style={{justifyContent: 'center', alignItems: 'center'}}>
        {!cur && !vertical && (
          <div style={{...textStyle, opacity: interpolate(frame, [20, 50], [0, 1], {extrapolateRight: 'clamp'})}}>
            <div style={{fontSize: 150, color: '#FFF8EC'}}>قبوله</div>
            <div style={{fontSize: 70, color: '#F2B04A', letterSpacing: 6, direction: 'ltr'}}>
              Ghabooleh
            </div>
          </div>
        )}

        {prev && cur && (
          <div
            style={{
              ...textStyle,
              fontSize: fontSize * 0.6,
              color: '#FFF8EC',
              opacity: interpolate(enter, [0, 1], [1, 0.3]),
              transform: `translateY(${-enter * (fontSize * 1.5)}px) scale(${interpolate(enter, [0, 1], [1, 0.8])})`,
              textShadow: '0 4px 24px rgba(0,0,0,0.7)',
            }}
          >
            {prev.text}
          </div>
        )}

        {cur && (
          <div
            style={{
              ...textStyle,
              fontSize,
              color: '#FFF8EC',
              opacity: enter,
              transform: `translateY(${(1 - enter) * 30}px) scale(${hitScale})`,
              filter: `blur(${(1 - enter) * 10}px)`,
              textShadow: `0 4px 30px rgba(0,0,0,0.8), 0 0 50px ${sp.color}66`,
            }}
          >
            <div
              style={{
                fontSize: fontSize * 0.38,
                color: sp.color,
                marginBottom: 14,
                letterSpacing: 2,
              }}
            >
              {sp.label}
            </div>
            {cur.text}
          </div>
        )}
      </AbsoluteFill>

      <AbsoluteFill style={{backgroundColor: '#F2B04A', opacity: flash, mixBlendMode: 'screen'}} />

      <div
        style={{
          position: 'absolute',
          bottom: 40,
          right: 56,
          fontFamily,
          fontSize: 30,
          letterSpacing: 8,
          color: '#FFF8EC',
          opacity: 0.8,
        }}
      >
        MEUZYK
      </div>

      <AbsoluteFill style={{backgroundColor: '#000', opacity: Math.max(fadeIn, fadeOut)}} />
    </AbsoluteFill>
  );
};
