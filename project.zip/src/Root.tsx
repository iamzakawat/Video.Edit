import React from 'react';
import {Composition, staticFile} from 'remotion';
import {getAudioDurationInSeconds} from '@remotion/media-utils';
import {LyricVideo, Props} from './LyricVideo';
import {parseLyrics} from './parse';

const FPS = 30;

const load = async () => {
  const [dur, txt] = await Promise.all([
    getAudioDurationInSeconds(staticFile('song.mp3')),
    fetch(staticFile('lyrics.txt')).then((r) => r.text()),
  ]);
  return {dur, lines: parseLyrics(txt, dur)};
};

const defaults: Props = {lines: [], vertical: false, offset: 0};

export const Root: React.FC = () => {
  return (
    <>
      <Composition
        id="Lyrics"
        component={LyricVideo}
        width={1920}
        height={1080}
        fps={FPS}
        durationInFrames={FPS * 180}
        defaultProps={defaults}
        calculateMetadata={async ({props}) => {
          const {dur, lines} = await load();
          return {
            durationInFrames: Math.ceil(dur * FPS),
            props: {...props, lines, vertical: false, offset: 0},
          };
        }}
      />
      <Composition
        id="Vertical"
        component={LyricVideo}
        width={1080}
        height={1920}
        fps={FPS}
        durationInFrames={FPS * 30}
        defaultProps={{...defaults, vertical: true}}
        calculateMetadata={async ({props}) => {
          const {dur, lines} = await load();
          const chorus = lines.filter((l) => l.section.toLowerCase().startsWith('chorus'));
          let from = 0;
          let to = Math.min(dur, 45);
          if (chorus.length) {
            const name = chorus[0].section;
            const group = chorus.filter((l) => l.section === name);
            from = Math.max(0, group[0].start - 1.5);
            to = Math.min(dur, group[group.length - 1].end + 1.5);
          }
          return {
            durationInFrames: Math.max(FPS, Math.ceil((to - from) * FPS)),
            props: {...props, lines, vertical: true, offset: from},
          };
        }}
      />
    </>
  );
};
