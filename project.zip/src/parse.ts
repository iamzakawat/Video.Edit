export type Line = {
  start: number;
  end: number;
  speaker: string;
  text: string;
  section: string;
};

type Raw = {start: number; speaker: string; text: string; section: string};

// Reads lyrics.txt lines like: [01:23.5] [Male] متن
// If every timestamp is 00:00.0, lines are spread evenly over the song (draft mode).
export function parseLyrics(txt: string, dur: number): Line[] {
  const raw: Raw[] = [];
  let section = '';
  for (const l0 of txt.split(/\r?\n/)) {
    const l = l0.trim();
    if (!l || l.startsWith('#')) continue;
    const sec = l.match(/^\((.+)\)$/);
    if (sec) {
      section = sec[1];
      continue;
    }
    const m = l.match(/^\[(\d+):(\d+(?:\.\d+)?)\]\s*\[(\w+)\]\s*(.+)$/);
    if (!m) continue;
    raw.push({
      start: parseInt(m[1], 10) * 60 + parseFloat(m[2]),
      speaker: m[3],
      text: m[4],
      section,
    });
  }
  if (raw.length && raw.every((r) => r.start === 0)) {
    const from = 3;
    const to = Math.max(from + raw.length, dur - 3);
    const total = raw.reduce((a, r) => a + r.text.length + 8, 0);
    let t = from;
    raw.forEach((r) => {
      r.start = t;
      t += ((to - from) * (r.text.length + 8)) / total;
    });
  }
  return raw.map((r, i) => ({
    ...r,
    end: i < raw.length - 1 ? raw[i + 1].start : Math.min(dur, r.start + 6),
  }));
}
